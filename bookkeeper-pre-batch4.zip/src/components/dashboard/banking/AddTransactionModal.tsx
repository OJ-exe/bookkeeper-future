"use client";

import { useState, type FormEvent } from "react";

import Modal from "@/components/ui/Modal";
import Button from "@/components/ui/Button";
import { type BankAccount, type BankTxn } from "@/data/banking";

const fieldClass =
  "w-full rounded-xl border border-line bg-canvas px-3 py-2.5 text-sm text-fg outline-none placeholder:text-muted focus:border-bronze transition";

function formatAmount(raw: string) {
  const trimmed = raw.trim();
  return trimmed.startsWith("₹") ? trimmed : `₹${trimmed}`;
}

function formatDate(raw: string) {
  if (!raw) return "—";
  const d = new Date(raw);
  if (Number.isNaN(d.getTime())) return raw;
  return d.toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" });
}

function toDateInput(raw: string) {
  if (!raw || raw === "—") return "";
  const d = new Date(raw);
  return Number.isNaN(d.getTime()) ? "" : d.toISOString().slice(0, 10);
}

function unblank(v: string | undefined) {
  return v && v !== "—" ? v : "";
}

export default function AddTransactionModal({
  open,
  onClose,
  onCreate,
  editing,
  onUpdate,
  accounts,
}: {
  open: boolean;
  onClose: () => void;
  onCreate: (txn: BankTxn) => void;
  editing?: BankTxn | null;
  onUpdate?: (item: BankTxn, patch: Partial<BankTxn>) => void;
  accounts: BankAccount[];
}) {
  const isEdit = !!editing;
  const [account, setAccount] = useState(editing?.account ?? accounts[0]?.name ?? "");
  const [date, setDate] = useState(toDateInput(editing?.date ?? ""));
  const [kind, setKind] = useState<BankTxn["kind"]>(editing?.kind ?? "Inflow");
  const [description, setDescription] = useState(editing?.description ?? "");
  const [reference, setReference] = useState(unblank(editing?.reference));
  const [amount, setAmount] = useState(unblank(editing?.amount));

  function reset() {
    setAccount(accounts[0]?.name ?? "");
    setDate("");
    setKind("Inflow");
    setDescription("");
    setReference("");
    setAmount("");
  }

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    if (description.trim() === "" || amount.trim() === "") return;
    if (isEdit && editing && onUpdate) {
      onUpdate(editing, {
        account,
        date: formatDate(date),
        kind,
        description: description.trim(),
        reference: reference.trim() || "—",
        amount: formatAmount(amount),
      });
      onClose();
      return;
    }
    onCreate({
      date: formatDate(date),
      description: description.trim(),
      reference: reference.trim() || "—",
      kind,
      amount: formatAmount(amount),
      account,
      status: "Unmatched",
    });
    reset();
    onClose();
  }

  function handleClose() {
    if (!isEdit) reset();
    onClose();
  }

  return (
    <Modal
      open={open}
      onClose={handleClose}
      title={isEdit ? "Edit Transaction" : "Add Transaction"}
      description="Record a bank or cash transaction against your ledger."
      footer={
        <>
          <Button variant="outline" onClick={handleClose}>
            Cancel
          </Button>
          <Button
            type="submit"
            form="add-transaction-form"
            variant="bronze"
            disabled={description.trim() === "" || amount.trim() === ""}
          >
            {isEdit ? "Save Changes" : "Add Transaction"}
          </Button>
        </>
      }
    >
      <form id="add-transaction-form" onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="txn-account" className="mb-1.5 block text-sm font-medium text-fg-soft">Account</label>
          <select
            id="txn-account"
            value={account}
            onChange={(e) => setAccount(e.target.value)}
            className={fieldClass}
          >
            {accounts.map((a) => (
              <option key={a.name} value={a.name}>
                {a.name} ({a.accountNo})
              </option>
            ))}
          </select>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label htmlFor="txn-date" className="mb-1.5 block text-sm font-medium text-fg-soft">Date</label>
            <input
              id="txn-date"
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className={fieldClass}
            />
          </div>
          <div>
            <label htmlFor="txn-type" className="mb-1.5 block text-sm font-medium text-fg-soft">Type</label>
            <select
              id="txn-type"
              value={kind}
              onChange={(e) => setKind(e.target.value as BankTxn["kind"])}
              className={fieldClass}
            >
              <option value="Inflow">Inflow</option>
              <option value="Outflow">Outflow</option>
            </select>
          </div>
        </div>

        <div>
          <label htmlFor="txn-description" className="mb-1.5 block text-sm font-medium text-fg-soft">
            Description <span className="text-danger">*</span>
          </label>
          <input
            id="txn-description"
            type="text"
            required
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="e.g. Receipt from ABC Pvt Ltd"
            className={fieldClass}
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label htmlFor="txn-reference" className="mb-1.5 block text-sm font-medium text-fg-soft">Reference</label>
            <input
              id="txn-reference"
              type="text"
              value={reference}
              onChange={(e) => setReference(e.target.value)}
              placeholder="NEFT / UTR / cheque no."
              className={fieldClass}
            />
          </div>
          <div>
            <label htmlFor="txn-amount" className="mb-1.5 block text-sm font-medium text-fg-soft">
              Amount <span className="text-danger">*</span>
            </label>
            <input
              id="txn-amount"
              type="text"
              inputMode="decimal"
              required
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="₹0.00"
              className={fieldClass}
            />
          </div>
        </div>

        <div>
          <label htmlFor="txn-notes" className="mb-1.5 block text-sm font-medium text-fg-soft">Notes</label>
          <textarea
            id="txn-notes"
            rows={3}
            placeholder="Add notes or context…"
            className={`${fieldClass} resize-none`}
          />
        </div>
      </form>
    </Modal>
  );
}

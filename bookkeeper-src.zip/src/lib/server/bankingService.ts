import { prisma } from "@/lib/prisma";
import type { Prisma } from "@/generated/prisma/client";

export async function getBankAccounts(userId: number) {
  return prisma.bankAccount.findMany({
    where: { userId },
    orderBy: { createdAt: "desc" },
  });
}

export async function getBankAccountById(userId: number, id: number) {
  return prisma.bankAccount.findFirst({
    where: { id, userId },
  });
}

export async function createBankAccount(
  userId: number,
  data: Omit<Prisma.BankAccountCreateInput, "user">
) {
  return prisma.bankAccount.create({
    data: {
      ...data,
      user: { connect: { id: userId } },
    },
  });
}

export async function getBankTransactions(userId: number) {
  return prisma.bankTransaction.findMany({
    where: { userId },
    include: { bankAccount: true, payment: true },
    orderBy: { createdAt: "desc" },
  });
}

export async function createBankTransaction(
  userId: number,
  data: Omit<Prisma.BankTransactionCreateInput, "user"> & {
    bankAccountId?: number | null;
    paymentId?: number | null;
  }
) {
  if (data.bankAccountId) {
    const acc = await prisma.bankAccount.findFirst({
      where: { id: data.bankAccountId, userId },
    });
    if (!acc) throw new Error("Bank account not found or unauthorized");
  }

  const { bankAccountId, paymentId, ...rest } = data;
  return prisma.bankTransaction.create({
    data: {
      ...rest,
      user: { connect: { id: userId } },
      ...(bankAccountId ? { bankAccount: { connect: { id: bankAccountId } } } : {}),
      ...(paymentId ? { payment: { connect: { id: paymentId } } } : {}),
    },
  });
}